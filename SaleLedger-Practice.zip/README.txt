SaleLedger practice files
=========================

These are FICTIONAL records for learning the workflow. They are not from a
real auction house. Never mix them with your own business records.

Files
  co_summary_report.csv   Auction Flex settlement export (Consignment Order totals)
  sample_export.iif       QuickBooks / IIF export from Pay Consignors
  bank_statement.csv      Trust account bank statement for August 2026

Values to enter under Option A
  Auction ID/number:          246
  Opening trust balance ($):  150000.00
  Reconciliation as-of date:  2026-08-31

Expected result
  OUT OF BALANCE with 8 exceptions. That is on purpose: the practice month
  contains a $500 overpayment, unexplained deposits, an unauthorized transfer
  to the operating account, and a bank fee, so you can see how each kind of
  problem is reported.

Tutorial: https://getsaleledger.com/tutorial.html
